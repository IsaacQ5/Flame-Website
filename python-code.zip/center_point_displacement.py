"""Collect and load per-test center-point offsets for folder measurements."""

import base64
import json
import os
import re
import tkinter as tk
from tkinter import filedialog, messagebox

import cv2


# Use the same extensions as the folder setup and measurement workflows so the
# calibration list and the eventual batch measurement list contain the same videos.
SUPPORTED_VIDEO_EXTS = (".mp4", ".avi", ".mov", ".mkv", ".wmv", ".ts")
def _displacement_filename(folder_path):
    """Build the default JSON filename from the folder containing the videos."""
    folder_name = os.path.basename(os.path.normpath(folder_path))
    return f"center_point_displacement_{folder_name}.json"


def _test_name(video_path):
    """Return the test label from a filename, or its stem when it has no test label."""
    # Strip the extension before searching so a file extension cannot be mistaken
    # for part of the test name.
    stem = os.path.splitext(os.path.basename(video_path))[0]
    # Filenames in the project use several separators and capitalization styles.
    match = re.search(r"test[\s_-]*[a-z0-9]+", stem, re.IGNORECASE)
    # Preserve a useful label even for files that do not include "Test <id>".
    return match.group(0) if match else stem


def load_center_point_displacements(path, video_names):
    """Load per-video pixel offsets, keyed by exact video filename.

    Offsets are applied to the center point currently selected for the folder;
    the original-center metadata saved in older files is intentionally ignored.
    """
    # Parse the sidecar file as UTF-8, the encoding used when it is written below.
    with open(path, "r", encoding="utf-8") as displacement_file:
        data = json.load(displacement_file)

    # Give a useful error when the JSON root has the wrong shape, rather than
    # failing later with an unrelated attribute error.
    if not isinstance(data, dict):
        raise ValueError(f"Displacement JSON must contain a JSON object: {path}")
    # Require a list so malformed data is reported before any video is measured.
    tests = data.get("tests")
    if not isinstance(tests, list):
        raise ValueError(f"Displacement JSON is missing the tests list: {path}")

    # Key by filename rather than test label: filenames uniquely identify the
    # video that must receive each offset, even when test labels repeat.
    by_video = {}
    for test in tests:
        if not isinstance(test, dict):
            raise ValueError(f"Invalid test entry in displacement JSON: {path}")
        video_name = test.get("video_name")
        displacement = test.get("displacement")
        if not isinstance(video_name, str) or not isinstance(displacement, dict):
            raise ValueError(f"Invalid test entry in displacement JSON: {path}")
        # Duplicate entries would make it ambiguous which saved offset to use.
        if video_name in by_video:
            raise ValueError(f"Duplicate video entry in displacement JSON: {video_name}")
        try:
            # Calibration offsets represent whole decoded-frame pixels; reject
            # invalid numeric values instead of silently rounding them.
            x_offset = displacement["x"]
            y_offset = displacement["y"]
            if (
                isinstance(x_offset, bool)
                or isinstance(y_offset, bool)
                or int(x_offset) != x_offset
                or int(y_offset) != y_offset
            ):
                raise ValueError("offsets must be whole pixel values")
            by_video[video_name] = (int(x_offset), int(y_offset))
        except (KeyError, OverflowError, TypeError, ValueError) as exc:
            raise ValueError(
                f"Invalid pixel displacement for {video_name}: {exc}"
            ) from exc

    # Ensure every current video was calibrated and no removed/renamed video
    # remains in the configuration, then return a direct filename lookup table.
    missing_videos = sorted(set(video_names) - set(by_video))
    extra_videos = sorted(set(by_video) - set(video_names))
    if missing_videos or extra_videos:
        details = []
        if missing_videos:
            details.append("missing: " + ", ".join(missing_videos))
        if extra_videos:
            details.append("no longer in folder: " + ", ".join(extra_videos))
        raise ValueError(
            "The saved displacement list does not match the selected folder ("
            + "; ".join(details)
            + "). Recalibrate the folder before measuring."
        )
    return by_video


class CenterPointDisplacementEditor(tk.Toplevel):
    """Show each video's first frame and collect arrow-key center offsets."""

    def __init__(
        self,
        master,
        video_paths,
        crop_rect,
        original_center_point,
        expected_frame_size,
    ):
        super().__init__(master)
        self.title("Set Center Points")
        self.geometry("1050x760")
        self.minsize(720, 520)
        # Treat calibration as a modal step within the setup UI so a second
        # calibration window cannot compete with the active folder configuration.
        self.transient(master)
        self.grab_set()

        # Store only source-frame coordinates and pixel offsets here. Display
        # scaling is applied only when drawing, never when adjusting a center.
        self.video_paths = video_paths
        self.crop_rect = tuple(int(value) for value in crop_rect)
        self.original_center_point = (
            float(original_center_point[0]),
            float(original_center_point[1]),
        )
        self.expected_frame_size = tuple(expected_frame_size)
        self.video_index = 0
        self.displacement_x = 0
        self.displacement_y = 0
        self.test_displacements = []
        self.current_frame = None
        self.tk_image = None
        self.display_scale = 1.0
        self.display_offset = (0, 0)
        self.result_path = None

        # Put the current filename, unchanged source center, and signed offset
        # above the preview so the user can track which test they are editing.
        info_frame = tk.Frame(self, padx=12, pady=10)
        info_frame.pack(fill="x")
        self.video_var = tk.StringVar()
        self.original_var = tk.StringVar()
        self.displacement_var = tk.StringVar()
        tk.Label(info_frame, textvariable=self.video_var, anchor="w").pack(fill="x")
        tk.Label(info_frame, textvariable=self.original_var, anchor="w").pack(fill="x")
        tk.Label(info_frame, textvariable=self.displacement_var, anchor="w").pack(fill="x")
        tk.Label(
            info_frame,
            text="Use the arrow keys to move one pixel per press. The crop and original point stay fixed.",
            anchor="w",
        ).pack(fill="x", pady=(4, 0))

        # The video and all markers share one canvas so their positions stay aligned.
        self.canvas = tk.Canvas(self, bg="#000000", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        self.canvas.bind("<Configure>", self._render_frame)

        footer = tk.Frame(self, padx=12, pady=10)
        footer.pack(fill="x")
        self.status_var = tk.StringVar(value="")
        tk.Label(footer, textvariable=self.status_var, anchor="w").pack(
            side="left", fill="x", expand=True
        )
        tk.Button(footer, text="Cancel", command=self.destroy).pack(side="right")
        tk.Button(footer, text="Next video", command=self.next_video).pack(
            side="right", padx=(0, 8)
        )

        # Window-level bindings continue to receive arrows after the user clicks
        # a button; returning "break" later prevents keys from triggering defaults.
        for key in ("<Left>", "<Right>", "<Up>", "<Down>"):
            self.bind(key, self._move_center)
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        try:
            # Display the first video immediately; close and propagate setup errors
            # so the parent UI can show a meaningful message.
            self._show_video()
        except (OSError, ValueError, RuntimeError):
            self.destroy()
            raise

    def _show_video(self):
        """Read the next video's first frame without changing the saved setup."""
        video_path = self.video_paths[self.video_index]
        capture = cv2.VideoCapture(video_path)
        try:
            # Calibration needs a still frame, so release the decoder immediately
            # after reading instead of holding a capture open for each test.
            ok, frame = capture.read()
        finally:
            capture.release()
        if not ok or frame is None:
            raise OSError(f"Could not read the first frame of {video_path}")

        # The shared crop, center, and scale were selected in the setup video.
        # Reject different frame sizes rather than misapplying those coordinates.
        height, width = frame.shape[:2]
        if (width, height) != self.expected_frame_size:
            raise ValueError(
                f"{os.path.basename(video_path)} has frame size {width}x{height}; "
                f"the setup video is {self.expected_frame_size[0]}x"
                f"{self.expected_frame_size[1]}. All folder videos must have "
                "matching dimensions."
            )

        # Each test begins at the original point; the user records a fresh
        # displacement for the current video rather than carrying one forward.
        self.current_frame = frame
        self.displacement_x = 0
        self.displacement_y = 0
        self.video_var.set(
            f"Video {self.video_index + 1} of {len(self.video_paths)}: "
            f"{os.path.basename(video_path)}  |  Test: {_test_name(video_path)}"
        )
        self.original_var.set(
            "Original center point: "
            f"({self.original_center_point[0]:g}, {self.original_center_point[1]:g})"
        )
        self._update_displacement_label()
        self.status_var.set("Adjust the center point, then select Next video.")
        self.after_idle(self._render_frame)
        self.canvas.focus_set()

    def _update_displacement_label(self):
        """Show signed movement from the original point on both axes."""
        self.displacement_var.set(
            f"Displacement: X {self.displacement_x:+d} px "
            f"(left is -1, right is +1); "
            f"Y {self.displacement_y:+d} px (up is -1, down is +1)"
        )

    def _move_center(self, event):
        """Apply one frame-pixel movement for an arrow-key press."""
        # Map keyboard directions to signed pixel deltas; the vertical axis
        # follows image coordinates, where increasing y points downward.
        direction = {
            "Left": (-1, 0),
            "Right": (1, 0),
            "Up": (0, -1),
            "Down": (0, 1),
        }.get(event.keysym)
        if direction is None:
            return "break"

        # Prevent the selected point from moving outside the video image.
        width = self.current_frame.shape[1]
        height = self.current_frame.shape[0]
        center_x = round(self.original_center_point[0]) + self.displacement_x
        center_y = round(self.original_center_point[1]) + self.displacement_y
        next_x = center_x + direction[0]
        next_y = center_y + direction[1]
        if 0 <= next_x < width and 0 <= next_y < height:
            # Deltas are maintained relative to the original center and never
            # multiplied by the preview's display scale.
            self.displacement_x += direction[0]
            self.displacement_y += direction[1]
            self._update_displacement_label()
            self._render_frame()
        return "break"

    def _render_frame(self, event=None):
        """Draw the frame and overlays while preserving their source coordinates."""
        if self.current_frame is None:
            return
        # A configure event gives the new canvas size directly; explicit renders
        # (after an arrow press) query the canvas because there is no event object.
        canvas_width = max(
            event.width if event is not None else self.canvas.winfo_width(),
            1,
        )
        canvas_height = max(
            event.height if event is not None else self.canvas.winfo_height(),
            1,
        )
        frame_height, frame_width = self.current_frame.shape[:2]
        # Fit the whole frame without stretching it, then center the letterboxed
        # image. The scale/offset are reused by all overlay coordinates.
        scale = min(canvas_width / frame_width, canvas_height / frame_height)
        render_width = max(1, int(frame_width * scale))
        render_height = max(1, int(frame_height * scale))
        offset_x = (canvas_width - render_width) // 2
        offset_y = (canvas_height - render_height) // 2
        self.display_scale = scale
        self.display_offset = (offset_x, offset_y)

        # Convert OpenCV's BGR frame into an encoded RGB image Tk can display.
        resized = cv2.resize(
            self.current_frame,
            (render_width, render_height),
            interpolation=cv2.INTER_AREA,
        )
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        ok, png = cv2.imencode(".png", rgb)
        if not ok:
            raise RuntimeError("Could not render the video frame for calibration.")
        self.tk_image = tk.PhotoImage(data=base64.b64encode(png.tobytes()))
        self.canvas.delete("all")
        self.canvas.create_image(offset_x, offset_y, anchor="nw", image=self.tk_image)

        # Draw the crop and original marker unchanged; the red marker alone
        # follows the accumulated arrow-key displacement.
        x1, y1, x2, y2 = self.crop_rect
        crop_top_left = self._frame_to_canvas(x1, y1)
        crop_bottom_right = self._frame_to_canvas(x2, y2)
        self.canvas.create_rectangle(
            *crop_top_left,
            *crop_bottom_right,
            outline="yellow",
            width=2,
        )
        original = self._frame_to_canvas(*self.original_center_point)
        current = self._frame_to_canvas(
            round(self.original_center_point[0]) + self.displacement_x,
            round(self.original_center_point[1]) + self.displacement_y,
        )
        self._draw_crosshair(*original, "deepskyblue")
        self._draw_crosshair(*current, "red")

    def _frame_to_canvas(self, x, y):
        """Convert frame-pixel coordinates to their preview-canvas positions."""
        # This transformation is for rendering only; measurements retain frame pixels.
        offset_x, offset_y = self.display_offset
        return (
            int(x * self.display_scale + offset_x),
            int(y * self.display_scale + offset_y),
        )

    def _draw_crosshair(self, x, y, color):
        """Draw a short crosshair centered on a preview position."""
        self.canvas.create_line(x - 9, y, x + 9, y, fill=color, width=2)
        self.canvas.create_line(x, y - 9, x, y + 9, fill=color, width=2)

    def next_video(self):
        """Record this video's offset and advance or save the completed JSON."""
        video_path = self.video_paths[self.video_index]
        # Keep both a readable test label and the exact filename used by the
        # measurement workflow to map this adjustment back to a video.
        self.test_displacements.append(
            {
                "test_name": _test_name(video_path),
                "video_name": os.path.basename(video_path),
                "displacement": {
                    "x": self.displacement_x,
                    "y": self.displacement_y,
                },
            }
        )
        self.video_index += 1
        if self.video_index < len(self.video_paths):
            try:
                # Reset and preview the next video; its offset starts at zero.
                self._show_video()
            except (OSError, ValueError, RuntimeError) as exc:
                messagebox.showerror("Center Point Setup", str(exc), parent=self)
                self.destroy()
            return

        # Save only after the user has confirmed every video. A partial set is
        # never treated as a complete calibration file.
        folder_path = os.path.dirname(self.video_paths[0])
        result_path = filedialog.asksaveasfilename(
            title="Save center-point displacements",
            initialdir=folder_path,
            initialfile=_displacement_filename(folder_path),
            defaultextension=".json",
            filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")],
            parent=self,
        )
        if not result_path:
            # Keep the final video's adjustment active so the user can retry.
            self.video_index -= 1
            self.test_displacements.pop()
            self.status_var.set("Choose a save location to finish calibration.")
            return

        data = {
            "original_center_point": {
                "x": self.original_center_point[0],
                "y": self.original_center_point[1],
            },
            "tests": self.test_displacements,
        }
        try:
            # The JSON records the fixed reference and per-video pixel deltas.
            with open(result_path, "w", encoding="utf-8") as displacement_file:
                json.dump(data, displacement_file, indent=2)
        except OSError as exc:
            # Keep the last video active so a transient write failure does not
            # discard its offset or falsely report that calibration succeeded.
            messagebox.showerror("Center Point Setup", str(exc), parent=self)
            self.video_index -= 1
            self.test_displacements.pop()
            return
        self.result_path = result_path
        messagebox.showinfo(
            "Center Point Setup",
            f"Saved offsets for {len(self.test_displacements)} videos.",
            parent=self,
        )
        self.destroy()


def collect_center_point_displacements(
    master,
    folder_path,
    crop_rect,
    original_center_point,
    frame_size,
):
    """Sort supported folder videos, run calibration, and return its saved path.

    Returns ``None`` if the user closes the calibration window before finishing.
    """
    # Use a deterministic ordering so the displayed sequence and saved list match
    # the folder measurement's sorted video sequence.
    video_paths = sorted(
        os.path.join(folder_path, name)
        for name in os.listdir(folder_path)
        if name.lower().endswith(SUPPORTED_VIDEO_EXTS)
    )
    if not video_paths:
        raise ValueError(f"No supported videos were found in {folder_path}")

    # The editor owns the modal interaction; wait_window returns only when it is
    # completed or cancelled, after which result_path communicates success.
    editor = CenterPointDisplacementEditor(
        master,
        video_paths,
        crop_rect,
        original_center_point,
        frame_size,
    )
    master.wait_window(editor)
    return editor.result_path