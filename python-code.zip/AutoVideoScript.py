import argparse
import json
import os

from VideoMeasurement import VideoMeasurement
from ui import collect_setup
from excel_utils import GenerateExcel
from forward_data import select_output_path
import time

# Auto batch measurement runner.
# - Collects UI settings (or loads from JSON)
# - Runs measurements for a folder
# - Generates a consolidated Excel output


def parse_args():
    # Support ui.py launching this script with a saved folder setup,
    # while preserving the original interactive batch flow.
    parser = argparse.ArgumentParser(
        description="Run flame measurement for all supported videos in a folder."
    )
    parser.add_argument(
        "--ui-settings",
        help="Path to JSON settings captured by ui.py.",
    )
    return parser.parse_args()


def load_ui_settings(settings_path):
    # Read the serialized UI selections back in so batch runs can start immediately.
    try:
        with open(settings_path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        print(f"UI settings file not found: {settings_path}")
        raise SystemExit(1)
    except json.JSONDecodeError as exc:
        print(f"Could not parse UI settings JSON from {settings_path}: {exc}")
        raise SystemExit(1)


def collect_or_load_ui_settings(args):
    if args.ui_settings:
        return load_ui_settings(args.ui_settings)
    # Fall back to the original interactive setup when no saved settings were supplied.
    return collect_setup(source_mode="folder", run_script=False)


def main():
    # Reset the "show measurement window" prompt once per run.
    VideoMeasurement.reset_show_window_prompt()
    # File extensions considered as videos for batch processing.
    supported_exts = (".mp4", ".avi", ".mov", ".mkv", ".wmv", ".ts")
    args = parse_args()

    # Either load UI-captured settings or collect them interactively.
    ui_settings = collect_or_load_ui_settings(args)
    if ui_settings is None:
        print("UI setup canceled. Exiting.")
        raise SystemExit(1)
    if ui_settings.get("source_mode") != "folder":
        # Safety: this script only handles folder mode.
        print("UI setup must use folder mode for AutoVideoScript. Exiting.")
        raise SystemExit(1)
    # Get the folder from UI settings.
    if ui_settings.get("folder_path"):
        Videos = ui_settings["folder_path"]
        videos_name = os.path.basename(Videos)
    else:
        print("UI settings missing folder or video path. Exiting.")
        raise SystemExit(1)

    # Require the user to choose the output location before processing.
    output_path = select_output_path(
        title="Choose where to save the batch data",
        default_name=f"MeasurementData{videos_name}.xlsx",
    )
    if not output_path:
        print("No output location selected. Exiting.")
        raise SystemExit(1)

    # Create the measurement object for this folder.
    run_video_measurement = VideoMeasurement(Videos, ui_settings=ui_settings)
    # Filter to supported video types and lock in a stable order so
    # processing order matches the labels written to Excel.
    run_video_measurement.list_of_videos = sorted(
        [
            name
            for name in run_video_measurement.list_of_videos
            if name.lower().endswith(supported_exts)
        ]
    )
    if not run_video_measurement.list_of_videos:
        print("No supported video files found in the selected folder. Exiting.")
        raise SystemExit(1)

    # One run-level timing so the user can see total runtime.
    start = time.perf_counter()

    if ui_settings and ui_settings.get("source_mode") == "folder" and not ui_settings.get("apply_to_all", True):
        # Per-video mode keeps the shared folder/output selection but asks
        # for crop/center/scale again for each file before measuring it.
        index = 1
        for name in run_video_measurement.list_of_videos:
            video_path = os.path.join(Videos, name)
            per_video_settings = collect_setup(
                initial_video_path=video_path,
                source_mode="single",
                folder_path=Videos,
                run_script=False,
            )
            if per_video_settings is None:
                print("UI setup canceled. Exiting.")
                raise SystemExit(1)
            # Reset derived state so the next video fully picks up its own settings.
            run_video_measurement.ui_settings = per_video_settings
            run_video_measurement.pixel_to_inches = 0.0
            run_video_measurement.CENTERX = 0
            run_video_measurement.CENTERY = 0
            run_video_measurement.croppedX = None
            run_video_measurement.croppedY = None
            run_video_measurement.SingleVideo(video_path, index)
            index += 1
    else:
        # Shared-settings mode reuses one crop/center/scale definition for the whole folder.
        run_video_measurement.loopThroughVideos()
    
    # Collect measurement results.
    excel_values = run_video_measurement.fetchExcelValue()
    
    # Fetch the list of measured videos (for labeling).
    list_of_videos = run_video_measurement.fetchListofVideos()
    
    # Create the Excel sheet for all videos measured.
    generate_excel = GenerateExcel(excel_values, list_of_videos)
    
    # Write output sheet content to disk.
    workbook = generate_excel.excel()
    
    # Save workbook to the required user-selected location.
    workbook.save(output_path)
    end = time.perf_counter()
    print("Code completed!")
    print(f'Finished in {end - start} seconds')


if (__name__ == '__main__'):
    main()
