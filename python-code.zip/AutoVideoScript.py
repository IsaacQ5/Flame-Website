from UI import ui_settings_json
from measurement_workflows import run_folder_measurement

# gets the data from the ui and runs the folder 
# with the same settings for each video
def main():
    ui_settings_json(source_mode="folder")
    run_folder_measurement()


if (__name__ == '__main__'):
    main()