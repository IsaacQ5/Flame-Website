import re
from pathlib import Path

import openpyxl
from openpyxl.chart import LineChart, Reference
from openpyxl.chart.axis import ChartLines
from openpyxl.chart.shapes import GraphicalProperties


# Paths for inputs/outputs used by the report generator.
THIS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = THIS_DIR.parent if THIS_DIR.name == "scripts" else THIS_DIR
DATA_DIR = PROJECT_ROOT / "Data"
REFERENCE_DATA_FILE = DATA_DIR / "DF Burner Standoff Distance Data-2b_4b_5b.xlsx"
OUTPUT_FILE = DATA_DIR / "PrecentDifference_all.xlsx"


def parse_test_number(header_value):
    """Extract numeric test id from header like 'Test183.ts'."""
    if not isinstance(header_value, str):
        return None
    match = re.search(r"Test(\d+)", header_value, flags=re.IGNORECASE)
    return int(match.group(1)) if match else None


def parse_measurement_suffix(measurement_path):
    """
    Build a short output suffix from names like:
    - MeasurementDataVideos2b.xlsx -> 2b
    - MeasurementDatavideos4b1.xlsx -> 4b1
    """
    stem = measurement_path.stem
    match = re.match(r"MeasurementData(?:Videos)?(.+)", stem, flags=re.IGNORECASE)
    if not match:
        return stem
    suffix = match.group(1).strip("_- ")
    return suffix or stem


def parse_design_key(name_or_suffix):
    """Map names like 4b1/4b2 -> 4b so reference data can be selected."""
    if not isinstance(name_or_suffix, str):
        return None
    match = re.search(r"(2b|4b|5b)", name_or_suffix, flags=re.IGNORECASE)
    return match.group(1).lower() if match else None


def list_measurement_files():
    """Return all batch measurement workbooks (skip single-video exports)."""
    return sorted(
        p for p in DATA_DIR.glob("MeasurementData*.xlsx")
        if not p.name.lower().startswith("singlemeasurementdata")
    )


def collect_distance_averages(measurement_ws):
    """
    Read distance averages from MeasurementDataVideos2b.
    Layout repeats every 6 columns:
    [Test, Distance AVG, Median, Displacement, Displacement AVG, separator].
    """
    averages_by_test = {}
    # Each measurement block is 6 columns wide.
    col = 1
    while col <= measurement_ws.max_column:
        header = measurement_ws.cell(row=1, column=col).value
        test_number = parse_test_number(header)
        if test_number is not None:
            avg_value = measurement_ws.cell(row=2, column=col + 1).value
            if isinstance(avg_value, (int, float)):
                averages_by_test[test_number] = float(avg_value)
        col += 6
    return averages_by_test


def collect_reference_measurements_by_design(reference_ws):
    """
    Read reference measurements from:
    DF Burner Standoff Distance Data-2b_4b_5b.xlsx
    Layout:
    - 2b: test col A(1), value col B(2)
    - 4b: test col D(4), value col E(5)
    - 5b: test col G(7), value col H(8)
    """
    design_cols = {
        "2b": (1, 2),
        "4b": (4, 5),
        "5b": (7, 8),
    }
    # Build a lookup of test_number -> reference value per design.
    reference = {key: {} for key in design_cols}
    for design_key, (test_col, value_col) in design_cols.items():
        for row in range(7, reference_ws.max_row + 1):
            test_value = reference_ws.cell(row=row, column=test_col).value
            data_value = reference_ws.cell(row=row, column=value_col).value
            if isinstance(test_value, (int, float)) and isinstance(data_value, (int, float)):
                reference[design_key][int(test_value)] = float(data_value)
    return reference


def write_section(ws, start_row, section_name, averages_by_test, reference_measurements):
    """
    Write one spaced section in the percent-difference worksheet.
    Returns (header_row, first_data_row, last_data_row).
    """
    ws.cell(row=start_row, column=1).value = f"Precent Difference - {section_name}"

    # Offset rows to leave whitespace between sections.
    header_row = start_row + 2
    unit_row = start_row + 3
    first_data_row = start_row + 4

    ws.cell(row=header_row, column=1).value = "Test"
    ws.cell(row=header_row, column=2).value = "Video Value"
    ws.cell(row=header_row, column=3).value = "Data meausurements "
    ws.cell(row=header_row, column=4).value = "Precent Difference "
    ws.cell(row=header_row, column=5).value = "Absolute Difference"

    ws.cell(row=unit_row, column=1).value = "#"
    ws.cell(row=unit_row, column=2).value = "(in)"
    ws.cell(row=unit_row, column=3).value = "(in)"
    ws.cell(row=unit_row, column=5).value = "(in)"

    sorted_tests = sorted(averages_by_test)
    if not sorted_tests:
        return header_row, None, None

    last_data_row = first_data_row + len(sorted_tests) - 1

    for idx, test_number in enumerate(sorted_tests):
        row = first_data_row + idx
        video_value = averages_by_test[test_number]
        data_value = reference_measurements.get(test_number)

        ws.cell(row=row, column=1).value = test_number
        ws.cell(row=row, column=2).value = video_value
        ws.cell(row=row, column=3).value = data_value

        if isinstance(data_value, (int, float)):
            # Percent difference relative to the mean of the two values.
            ws.cell(row=row, column=4).value = f"=(ABS(B{row}-C{row})/((B{row}+C{row})/2))*100%"
            ws.cell(row=row, column=5).value = f"=ABS(B{row}-C{row})"

    return header_row, first_data_row, last_data_row


def add_chart(ws, header_row, first_row, last_row, anchor_cell, section_name):
    """Create marker-only chart with video values and measurements vs. test number."""
    if first_row is None or last_row is None:
        return

    chart = LineChart()
    chart.title = f"Video Values vs Data Measurements ({section_name})"
    chart.style = 2
    chart.y_axis.title = "Value (in)"
    chart.x_axis.title = "Video Test Number"

    # Use columns B (Video Value) and C (Data Measurements) as series.
    data = Reference(ws, min_col=2, max_col=3, min_row=header_row, max_row=last_row)
    cats = Reference(ws, min_col=1, min_row=first_row, max_row=last_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)

    # Show dots only (no connecting lines).
    for series in chart.series:
        series.marker.symbol = "circle"
        series.marker.size = 7
        series.graphicalProperties.line.noFill = True

    # Draw vertical connector/error lines between the two series at each test number.
    chart.hiLowLines = ChartLines()
    chart.hiLowLines.spPr = GraphicalProperties()
    chart.hiLowLines.spPr.ln.solidFill = "000000"
    chart.hiLowLines.spPr.ln.w = 38100  # Thick black line (~3 pt)

    chart.height = 9
    chart.width = 16

    ws.add_chart(chart, anchor_cell)


def main():
    # Discover all measurement workbooks.
    measurement_files = list_measurement_files()
    if not measurement_files:
        print(f"No measurement files found in {DATA_DIR}.")
        return

    # Load reference measurements for 2b/4b/5b.
    reference_wb = openpyxl.load_workbook(REFERENCE_DATA_FILE, data_only=True, read_only=True)
    reference_ws = reference_wb.active
    reference_by_design = collect_reference_measurements_by_design(reference_ws)

    # Create output workbook and iterate over measurement files.
    output_wb = openpyxl.Workbook()
    output_ws = output_wb.active
    output_ws.title = "Sheet1"

    start_row = 1
    for measurement_file in measurement_files:
        # Read averages from each measurement workbook.
        measurement_wb = openpyxl.load_workbook(
            measurement_file,
            data_only=True,
            read_only=True
        )
        measurement_ws = measurement_wb.active
        averages_by_test = collect_distance_averages(measurement_ws)
        section_name = parse_measurement_suffix(measurement_file)
        design_key = parse_design_key(section_name)
        reference_measurements = reference_by_design.get(design_key, {})

        header_row, first_row, last_row = write_section(
            output_ws,
            start_row,
            section_name,
            averages_by_test,
            reference_measurements
        )
        add_chart(
            output_ws,
            header_row,
            first_row,
            last_row,
            f"G{start_row}",
            section_name
        )

        if last_row is None:
            start_row += 12
        else:
            start_row = last_row + 5

        print(
            f"Loaded values from {measurement_file.name} into section {section_name} "
            f"using {design_key or 'unknown'} reference data."
        )

    try:
        # Save to the primary output path.
        output_wb.save(OUTPUT_FILE)
        print(f"Saved combined workbook to {OUTPUT_FILE}.")
    except PermissionError:
        # Fallback if the primary file is open/locked.
        fallback_path = DATA_DIR / "PrecentDifference_all_updated.xlsx"
        output_wb.save(fallback_path)
        print(
            f"Could not overwrite {OUTPUT_FILE} (file is open/locked). "
            f"Saved updated workbook to {fallback_path}."
        )


if __name__ == "__main__":
    main()
