import argparse
import json
import os

from VideoMeasurement import VideoMeasurement
from ui import collect_setup
from excel_utils import GenerateExcel
from forward_data import select_output_path
import time


def parse_args():
    # Support ui.py launching this script with a saved settings file,
    # while still allowing direct CLI use for one-off runs.
    parser = argparse.ArgumentParser(
        description="Run flame measurement for a single video."
    )
    parser.add_argument(
        "--ui-settings",
        help="Path to JSON settings captured by ui.py.",
    )
    parser.add_argument(
        "--video",
        help="Optional single-video path to pre-load or override the settings file.",
    )
    return parser.parse_args()


def load_ui_settings(settings_path):
    # Read the serialized UI selections back in so we can skip reopening setup.
    try:
        with open(settings_path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        print(f"UI settings file not found: {settings_path}")
        raise SystemExit(1)
    except json.JSONDecodeError as exc:
        print(f"Could not parse UI settings JSON from {settings_path}: {exc}")
        raise SystemExit(1)


def collect_or_load_ui_settings(args):
    if args.ui_settings:
        ui_settings = load_ui_settings(args.ui_settings)
        # Allow the caller to swap in a different file without rebuilding
        # the rest of the saved crop/center/scale settings.
        if args.video:
            ui_settings["video_path"] = args.video
        return ui_settings
    # Fall back to the original interactive flow when no CLI settings were provided.
    return collect_setup(
        initial_video_path=args.video,
        source_mode="single",
        run_script=False,
    )


def main():
    # One run-level timing so the user can see total runtime.
    start = time.perf_counter()
    # Reset the "show measurement window" prompt once per run.
    VideoMeasurement.reset_show_window_prompt()
    args = parse_args()

    # Either load UI-captured settings or collect them interactively.
    ui_settings = collect_or_load_ui_settings(args)
    if ui_settings is None:
        print("UI setup canceled. Exiting.")
        raise SystemExit(1)
    if ui_settings.get("source_mode") != "single":
        # Safety: this script only handles single mode.
        print("UI setup must use single mode for SingleVideo. Exiting.")
        raise SystemExit(1)

    if ui_settings.get("source_mode") == "single" and ui_settings.get("video_path"):
        # The measurement class expects a folder root plus a filename.
        single_video_path = ui_settings["video_path"]
        video_folder = os.path.dirname(single_video_path)
        run_video_measurement = VideoMeasurement(video_folder, ui_settings=ui_settings)
        single_video = os.path.basename(single_video_path)
    else:
        print("UI settings missing video path. Exiting.")
        raise SystemExit(1)

    # Require the user to choose the output location before processing.
    output_path = select_output_path(
        title="Choose where to save the single-video data",
        default_name=f"SingleMeasurementData{single_video}.xlsx",
    )
    if not output_path:
        print("No output location selected. Exiting.")
        raise SystemExit(1)
            
    # Run the measurement for a single video.
    run_video_measurement.SingleVideo(run_video_measurement.video_path +'/'+ single_video)

    # Fetch the measurement results.
    excel_values = run_video_measurement.fetchExcelValue()
    
    # Generate the Excel sheet for the single video.
    workbook = GenerateExcel(excel_values).excel(single_video)
    
    # Save workbook to the required user-selected location.
    workbook.save(output_path)
    end = time.perf_counter()
    print("Code completed!")
    print(f'Finished in {end - start} seconds')


if (__name__ == '__main__'):
    main()
