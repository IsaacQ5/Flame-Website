import json
import os
import sys


SETTINGS_FILENAME = "ui_settings.json"
EXCEL_VALUES_FILENAME = "measurement_results.json"
MEASUREMENT_SETTINGS_KEYS = (
    "video_path",
    "crop_rect",
    "center_point",
    "pixel_to_inches",
    "frame_size",
    "source_mode",
    "folder_path",
)


def resolve_data_path(filename):
    """Store data next to the exe in portable builds, otherwise at repo root."""
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
    else:
        this_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.dirname(this_dir) if os.path.basename(this_dir) == "scripts" else this_dir
    return os.path.join(base_dir, filename)


def resolve_settings_path():
    '''Get the path to the settings file, resolving it based on whether we're in a portable build or not.'''
    return resolve_data_path(SETTINGS_FILENAME)


SETTINGS_PATH = resolve_settings_path()
EXCEL_VALUES_PATH = resolve_data_path(EXCEL_VALUES_FILENAME)


def load_settings_file(path=SETTINGS_PATH):
    ''''Reads a JSON file from the given path and returns it as a dictionary. If the file doesn't exist, returns an empty dictionary.'''
    if not os.path.exists(path):
        return {}

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    return data


def _load_settings_file_or_empty(path):
    '''Helper function to load settings file, returning an empty dict if the file is missing or malformed.'''
    try:
        return load_settings_file(path)
    except Exception:
        return {}


def save_settings_file(data, path=SETTINGS_PATH):
    '''Writes the given dictionary to a JSON file at the specified path. Creates directories if needed.'''
    output_dir = os.path.dirname(path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def save_measurement_settings(settings, path=SETTINGS_PATH):
    ''''Saves the provided measurement settings to the settings file, merging with existing settings if the file already exists.'''
    data = _load_settings_file_or_empty(path)
    data.update(settings)
    data["settings_path"] = os.path.abspath(path)
    save_settings_file(data, path)
    return os.path.abspath(path)


def load_measurement_settings(path=SETTINGS_PATH):
    '''Loads measurement settings from the settings file, returning only the keys relevant to measurement.'''
    data = load_settings_file(path)
    return {
        key: data[key]
        for key in MEASUREMENT_SETTINGS_KEYS
        if key in data
    }


def save_excel_values(excel_values, list_of_videos=None, path=EXCEL_VALUES_PATH):
    '''Saves the provided Excel values and list of videos to a JSON file for later use in generating the Excel workbook.'''
    data = {
        "excel_values": excel_values,
        "list_of_videos": list(list_of_videos or []),
        "results_path": os.path.abspath(path),
    }
    save_settings_file(data, path)
    return os.path.abspath(path)


def load_excel_values(path=EXCEL_VALUES_PATH):
    ''''Loads Excel values and list of videos from the specified JSON file, returning them as a tuple.'''
    data = load_settings_file(path)
    excel_values = data.get("excel_values")
    if not isinstance(excel_values, dict):
        raise ValueError(f"Measurement results JSON missing 'excel_values': {path}")
    return excel_values, data.get("list_of_videos") or []
