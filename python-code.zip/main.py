import os
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox


SCRIPT_OPTIONS = {
    "single video": {
        "script": "SingleVideo.py",
    },
    "folder of videos": {
        "script": "AutoVideoScript.py",
    },
}


def resolve_launcher_dir():
    '''Returns the directory containing the launcher script.'''
    return os.path.dirname(os.path.abspath(__file__))


def build_candidate_dirs():
    ''''Returns a list of directories to search for measurement scripts, 
    starting with the most likely locations.'''
    launcher_dir = resolve_launcher_dir()
    parent_dir = os.path.dirname(launcher_dir)
    candidate_dirs = []
    for candidate_dir in (
        launcher_dir,
        os.path.join(launcher_dir, "scripts"),
        parent_dir,
        os.path.join(parent_dir, "scripts"),
    ):
        if candidate_dir not in candidate_dirs:
            candidate_dirs.append(candidate_dir)
    return candidate_dirs


def resolve_script_path(script_name):
    '''Searches candidate directories for the given script name and 
    returns the full path if found.'''
    candidate_dirs = build_candidate_dirs()
    for candidate_dir in candidate_dirs:
        script_path = os.path.join(candidate_dir, script_name)
        if os.path.exists(script_path):
            return script_path, candidate_dirs

    return None, candidate_dirs


class LauncherUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Flame Measurement Launcher")
        self.geometry("260x120")
        self.resizable(False, False)

        self._build_ui()
        self._center_window()
        self.bind("<Escape>", lambda _event: self.destroy())

    def _build_ui(self):
        '''Creates the buttons for each measurement workflow option.'''
        container = tk.Frame(self, padx=16, pady=16)
        container.pack(fill="both", expand=True)
        for label in SCRIPT_OPTIONS:
            tk.Button(
                container,
                text=label,
                width=18,
                command=lambda selected=label: self.launch_script(selected),
            ).pack(pady=6)

    def _center_window(self):
        '''Centers the launcher window on the screen.'''
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() - width) // 2
        y = (self.winfo_screenheight() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")

    def launch_script(self, selection):
        '''Launches the measurement workflow script corresponding to the given selection.'''
        option = SCRIPT_OPTIONS[selection]
        script_path, candidate_dirs = resolve_script_path(option["script"])

        if script_path is None:
            messagebox.showerror(
                "Missing Script",
                f"Could not find {option['script']} in:\n" + "\n".join(candidate_dirs),
                parent=self,
            )
            return

        try:
            # Launch the chosen workflow in a separate Python process so the
            # launcher can close cleanly before the measurement UI appears.
            subprocess.Popen(
                [sys.executable, script_path],
                cwd=os.path.dirname(script_path),
            )
        except OSError as exc:
            messagebox.showerror(
                "Launch Failed",
                f"Could not start {option['script']}:\n{exc}",
                parent=self,
            )
            return

        self.destroy()


def main():
    app = LauncherUI()
    app.mainloop()


if __name__ == "__main__":
    main()
