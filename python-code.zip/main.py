'''
Author: Isaac Quevy
Date: 04/02/2026
'''
import tkinter as tk
from tkinter import messagebox

from AutoVideoScript import main as run_folder_measurement_workflow
from SingleVideo import main as run_single_video_measurement_workflow

# scripts that will be able to be ran from the ui 
# put in dict for scalability just incase of anymore options  
RUNABLE_SCRIPTS = {
    "single video": {
        "runner": run_single_video_measurement_workflow,
    },
    "folder of videos": {
        "runner": run_folder_measurement_workflow,
    },
}

#The tkinter ui but in a class to pass the root through functions easier
class TK_UI(tk.Tk):
    def __init__(self):
        # make tk.tk the super class makes "self" the tk class
        # so when "self" is called, you don't need to "self.tk" bc tk is self
        super().__init__()
        
        
        self.title("Flame Measurement Launcher")
        self.geometry("520x240")

        self._build_ui()
        self._center_window()
        #if the ui is closed out
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.bind("<Escape>", self.on_closing )

    def _build_ui(self):
        '''creates buttons for every runable script'''
        #creates a frame or a field for the buttons to be in 
        container = tk.Frame(self, padx=10, pady=10, background="#0A0909")
        container.pack(fill="both", expand=True)
        
        # Create a button for each runable script 
        for key in RUNABLE_SCRIPTS:
            tk.Button(
                container,
                text=key,
                width=50,
                height=5,
                background="#999BB4",
                #the script running 
                command=lambda selected=key: self.launch_workflow(selected),
            ).pack(pady=6)

    def _center_window(self):
        '''Centers the launcher window on the screen.'''
        #refreshes the ui after new geomtry is set 
        self.update_idletasks()
        
        #centers the window once the ui is refreshed 
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() - width) // 2
        y = (self.winfo_screenheight() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")
        

    def launch_workflow(self, selection):
        """Run the selected workflow in-process so it also works when frozen."""
        #pulls the script to run 
        option = RUNABLE_SCRIPTS[selection]
        runner = option["runner"]
        
        #removes the ui
        self.destroy()
        
        #runs script 
        runner()
    
    def on_closing(self):
        '''double checks if you want to window closed'''    
        if messagebox.askyesno(title="Close?", message="Do you really want to close? "):
            self.destroy()


def main():
    app = TK_UI()
    #runs tk
    app.mainloop()


if __name__ == "__main__":
    main()
