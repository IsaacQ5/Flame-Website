'''
Author: Isaac Quevy
Date: 04/02/2026
'''
import tkinter as tk
from tkinter import messagebox

from AutoVideoScript import main as run_folder_measurement_workflow
from SingleVideo import main as run_single_video_measurement_workflow


RUNABLE_SCRIPTS = {
    "single video": {
        "runner": run_single_video_measurement_workflow,
    },
    "folder of videos": {
        "runner": run_folder_measurement_workflow,
    },
}


def show_unexpected_error(title, message):
    """if you close the window, this error will show"""
    error_root = tk.Tk()
    error_root.withdraw()
    try:
        messagebox.showerror(title, message, parent=error_root)
    finally:
        error_root.destroy()


class LauncherUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Flame Measurement Launcher")
        self.geometry("260x120")
        self.resizable(False, False)

        self._build_ui()
        self._center_window()
        self.bind("<Escape>", lambda _event: self.destroy())

    def _build_ui(self):
        '''Creates the buttons for each measurement option (single, or folder).'''
        container = tk.Frame(self, padx=16, pady=16)
        container.pack(fill="both", expand=True)
        # Create a button for option in runable scripts
        for key in RUNABLE_SCRIPTS:
            tk.Button(
                container,
                text=key,
                width=18,
                #the script running 
                command=lambda selected=key: self.launch_workflow(selected),
            ).pack(pady=6)

    def _center_window(self):
        '''Centers the launcher window on the screen.'''
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() - width) // 2
        y = (self.winfo_screenheight() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")

    def launch_workflow(self, selection):
        """Run the selected workflow in-process so it also works when frozen."""
        option = RUNABLE_SCRIPTS[selection]
        runner = option["runner"]
        self.destroy()
        try:
            runner()
        # if the script doesn't run, raise these errors 
        except SystemExit as exc:
            if isinstance(exc.code, str) and exc.code.strip():
                show_unexpected_error("Workflow Error", exc.code)
        except Exception as exc:
            show_unexpected_error(
                "Launch Failed",
                f"Could not start the {selection} workflow:\n{exc}",
            )


def main():
    app = LauncherUI()
    app.mainloop()


if __name__ == "__main__":
    main()
