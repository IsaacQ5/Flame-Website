import os
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox


SCRIPT_OPTIONS = {
    "single video": {
        "script": "SingleVideo.py",
    },
    "folder of videos": {
        "script": "AutoVideoScript.py",
    },
}


def resolve_project_root():
    this_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(this_dir) == "scripts":
        return os.path.dirname(this_dir)
    return this_dir


def resolve_script_path(script_name):
    this_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = resolve_project_root()
    candidate_dirs = []
    for candidate_dir in (this_dir, project_root, os.path.join(project_root, "scripts")):
        if candidate_dir not in candidate_dirs:
            candidate_dirs.append(candidate_dir)

    for candidate_dir in candidate_dirs:
        script_path = os.path.join(candidate_dir, script_name)
        if os.path.exists(script_path):
            return script_path

    return None


class LauncherUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Flame Measurement Launcher")
        self.geometry("260x120")
        self.resizable(False, False)

        self._build_ui()
        self._center_window()
        self.bind("<Escape>", lambda _event: self.destroy())

    def _build_ui(self):
        container = tk.Frame(self, padx=16, pady=16)
        container.pack(fill="both", expand=True)
        for label in SCRIPT_OPTIONS:
            tk.Button(
                container,
                text=label,
                width=18,
                command=lambda selected=label: self.launch_script(selected),
            ).pack(pady=6)

    def _center_window(self):
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() - width) // 2
        y = (self.winfo_screenheight() - height) // 2
        self.geometry(f"{width}x{height}+{x}+{y}")

    def launch_script(self, selection):
        option = SCRIPT_OPTIONS[selection]
        project_root = resolve_project_root()
        script_path = resolve_script_path(option["script"])

        if script_path is None:
            messagebox.showerror(
                "Missing Script",
                f"Could not find {option['script']} next to the launcher or in:\n{project_root}",
                parent=self,
            )
            return

        try:
            # Launch the chosen workflow in a separate Python process so the
            # launcher can close cleanly before the measurement UI appears.
            subprocess.Popen([sys.executable, script_path], cwd=project_root)
        except OSError as exc:
            messagebox.showerror(
                "Launch Failed",
                f"Could not start {option['script']}:\n{exc}",
                parent=self,
            )
            return

        self.destroy()


def main():
    app = LauncherUI()
    app.mainloop()


if __name__ == "__main__":
    main()
