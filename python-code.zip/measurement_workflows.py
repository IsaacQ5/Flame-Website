import os
import tkinter as tk
from tkinter import ttk

from VideoMeasurement import VideoMeasurement
from excel_utils import GenerateExcel
from forward_data import select_output_path
from settings_store import load_measurement_settings, SETTINGS_PATH


SUPPORTED_VIDEO_EXTS = (".mp4", ".avi", ".mov", ".mkv", ".wmv", ".ts")


class FolderProgressWindow:
    def __init__(self, total_videos):
        
        self.total_videos = max(1, total_videos)
        # We create a single root window for the entire progress dialog 
        # to avoid issues with multiple Tk instances.
        self.root = VideoMeasurement._ensure_tk_root()
        self.window = tk.Toplevel(self.root)
        self.window.title("Folder Measurement Progress")
        self.window.resizable(False, False)
        self.window.protocol("WM_DELETE_WINDOW", self._ignore_close)

        container = tk.Frame(self.window, padx=16, pady=16)
        container.pack(fill="both", expand=True)

        self.status_var = tk.StringVar(value="Preparing folder measurement...")
        self.video_var = tk.StringVar(value="Current video: --")
        self.count_var = tk.StringVar(value=f"0 of {self.total_videos} completed")

        # UI elements for progress display
        tk.Label(container, text="Batch progress", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        tk.Label(container, textvariable=self.status_var, anchor="w", justify="left").pack(
            fill="x", pady=(10, 4)
        )
        tk.Label(container, textvariable=self.video_var, anchor="w", justify="left", wraplength=420).pack(
            fill="x"
        )
        tk.Label(container, textvariable=self.count_var, anchor="w", justify="left").pack(
            fill="x", pady=(6, 8)
        )

        # Progress bar for visual feedback on batch progress.
        self.progress = ttk.Progressbar(
            container,
            orient="horizontal",
            mode="determinate",
            maximum=self.total_videos,
            length=420,
        )
        self.progress.pack(fill="x")
        self._refresh()

    def _ignore_close(self):
        '''Prevents the user from closing the progress window during processing.'''
        return

    def _refresh(self):
        '''Refreshes the progress window to show updated information.'''
        try:
            self.window.update_idletasks()
            self.window.update()
        except tk.TclError:
            pass

    def set_pending(self, index, video_name):
        '''Sets the progress window to indicate the next video about to be processed.'''
        self.status_var.set(f"Preparing video {index} of {self.total_videos}...")
        self.video_var.set(f"Current video: {video_name}")
        self.count_var.set(f"{max(0, index - 1)} of {self.total_videos} completed")
        self.progress["value"] = max(0, index - 1)
        self._refresh()

    def set_active(self, index, video_name):
        '''Updates the progress window to show the currently active video and progress.'''
        self.status_var.set(f"Measuring video {index} of {self.total_videos}...")
        self.video_var.set(f"Current video: {video_name}")
        self.count_var.set(f"{max(0, index - 1)} of {self.total_videos} completed")
        self.progress["value"] = max(0, index - 1)
        self._refresh()

    def finish(self):
        '''Updates the progress window to indicate that all videos have been processed.'''
        self.status_var.set("Folder measurement complete.")
        self.video_var.set("Current video: complete")
        self.count_var.set(f"{self.total_videos} of {self.total_videos} completed")
        self.progress["value"] = self.total_videos
        self._refresh()

    def close(self):
        '''Closes the progress window.'''
        try:
            if self.window.winfo_exists():
                self.window.destroy()
        except tk.TclError:
            pass


def _load_ui_settings():
    """Load measurement settings saved by the setup UI."""
    ui_settings = load_measurement_settings(SETTINGS_PATH)
    if not ui_settings:
        raise SystemExit(f"Could not read measurement settings from {SETTINGS_PATH}")
    return ui_settings


def run_single_video_measurement():
    # Run the single-video workflow using settings collected from the setup UI.
    ui_settings = _load_ui_settings()
    VideoMeasurement.reset_show_window_prompt()

    # Set up the video measurement instance with the provided video path and UI settings.
    single_video_path = ui_settings["video_path"]
    video_folder = os.path.dirname(single_video_path)
    single_video = os.path.basename(single_video_path)
    run_video_measurement = VideoMeasurement(
        video_folder,
        ui_settings=ui_settings,
        settings_path=SETTINGS_PATH,
    )

    # Prompt the user to select an output path for the Excel file, 
    # with a default name based on the video filename.
    output_path = select_output_path(
        title="Choose where to save the single-video data",
        default_name=f"SingleMeasurementData{single_video}.xlsx",
    )

    if not output_path:
        #print("No output location selected. Exiting.")
        raise SystemExit(1)

    run_video_measurement.SingleVideo(
        os.path.join(run_video_measurement.video_path, single_video)
    )

    # After processing the video, write the measurement values to JSON,
    # generate the workbook from that JSON, then save it.
    excel_values_path = run_video_measurement.saveExcelValueJson([single_video])
    workbook = GenerateExcel(excel_values_path).excel(single_video)
    workbook.save(output_path)

    VideoMeasurement.cleanup_tk_root()


def run_folder_measurement():
    # Run the folder workflow using settings collected from the setup UI.
    ui_settings = _load_ui_settings()
    VideoMeasurement.reset_show_window_prompt()
    progress_window = None

    # Set up the video measurement instance with the provided folder path and UI settings.
    videos_path = ui_settings["folder_path"]
    videos_name = os.path.basename(videos_path)
    output_path = select_output_path(
        title="Choose where to save the batch data",
        default_name=f"MeasurementData{videos_name}.xlsx",
    )
    if not output_path:
        #print("No output location selected. Exiting.")
        raise SystemExit(1)


    run_video_measurement = VideoMeasurement(
        videos_path,
        ui_settings=ui_settings,
        settings_path=SETTINGS_PATH,
    )
    
    #filter for supported video files and sort them
    run_video_measurement.list_of_videos = sorted(
        [
            name
            for name in run_video_measurement.list_of_videos
            if name.lower().endswith(SUPPORTED_VIDEO_EXTS)
        ]
    )
    if not run_video_measurement.list_of_videos:
        #print("No supported video files found in the selected folder. Exiting.")
        raise SystemExit(1)

    total_videos = len(run_video_measurement.list_of_videos)
    progress_window = FolderProgressWindow(total_videos)

    def update_progress(index, video_path=None):
        '''Updates the progress window with the current video being processed and overall progress.'''
        progress_window.set_active(index, os.path.basename(video_path) if video_path else "--")

    # Always apply the same settings to all videos
    run_video_measurement.loopThroughVideos(progress_callback=update_progress)

    # After processing all videos, write the measurement values to JSON,
    # generate the workbook from that JSON, and save it.
    excel_values_path = run_video_measurement.saveExcelValueJson()
    workbook = GenerateExcel(excel_values_path).excel()
    workbook.save(output_path)
    progress_window.finish()


    if progress_window is not None:
        progress_window.close()
    VideoMeasurement.cleanup_tk_root()
