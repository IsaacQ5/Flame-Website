import json
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox


SETTINGS_KEY = "last_output_dir"


def _resolve_settings_path():
    """Save portable-build settings next to the exe, otherwise next to the repo."""
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
    else:
        this_dir = os.path.dirname(os.path.abspath(__file__))
        base_dir = os.path.dirname(this_dir) if os.path.basename(this_dir) == "scripts" else this_dir
    return os.path.join(base_dir, "ui_settings.json")


SETTINGS_PATH = _resolve_settings_path()


def _load_last_output_dir():
    # Read the last output directory from settings if available.
    if not os.path.exists(SETTINGS_PATH):
        return None
    try:
        # If the file exists but is malformed, 
        # we catch the exception and return None to avoid blocking the user.
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get(SETTINGS_KEY)
    except Exception:
        return None


def _save_last_output_dir(path):
    # Persist the chosen directory for the next save dialog.
    try:
        data = {}
        if os.path.exists(SETTINGS_PATH):
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
        data[SETTINGS_KEY] = path
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        # If saving fails, proceed without blocking the user.
        pass


def select_output_path(
    title="Choose where to save the data",
    default_name="MeasurementData.xlsx",
):
    root = tk.Tk()
    root.withdraw()
    initial_dir = _load_last_output_dir()
    path = filedialog.asksaveasfilename(
        title=title,
        defaultextension=".xlsx",
        initialfile=default_name,
        initialdir=initial_dir,
        filetypes=[
            ("Excel Workbook", "*.xlsx"),
            ("All Files", "*.*"),
        ],
    )
    root.destroy()
    if path:
        _save_last_output_dir(os.path.dirname(path))
        return path
    return None


def main():
    path = select_output_path()
    if path:
        messagebox.showinfo("Selected Path", f"Data will be saved to:\n{path}")
        print(path)
    else:
        messagebox.showwarning("No Selection", "No location selected.")


if __name__ == "__main__":
    main()
