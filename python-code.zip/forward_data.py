import tkinter as tk
from tkinter import filedialog, messagebox


def select_output_path(
    title="Choose where to save the data",
    default_name="MeasurementData.xlsx",
):
    '''Opens a file dialog for the user to select where to save the Excel output.'''
    root = tk.Tk()
    root.withdraw()
    path = filedialog.asksaveasfilename(
        title=title,
        defaultextension=".xlsx",
        initialfile=default_name,
        filetypes=[
            ("Excel Workbook", "*.xlsx"),
            ("All Files", "*.*"),
        ],
    )
    root.destroy()
    if path:
        return path
    return None


def main():
    path = select_output_path()
    if path:
        messagebox.showinfo("Selected Path", f"Data will be saved to:\n{path}")
        #print(path)
    else:
        messagebox.showwarning("No Selection", "No location selected.")


if __name__ == "__main__":
    main()
