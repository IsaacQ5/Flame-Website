import os
import statistics
import openpyxl as excelSheet
from openpyxl.styles import PatternFill
import re
from settings_store import load_excel_values, load_measurement_settings

# A solid black fill pattern used to visually separate sections in the Excel output.
BLACKFILL = PatternFill(start_color="FF000000", end_color="FF000000", fill_type="solid")

REMOVED_VALUES = 0  # Number of values to highlight in red and exclude from non-red average.


class GenerateExcel:
    def __init__(self, excel_values_json_path, workbook=None):
        # Load measured distance values from the JSON file written by VideoMeasurement.
        self.excel_values, self.list_of_videos = load_excel_values(excel_values_json_path)

        self.measurement_params = load_measurement_settings()
        #print(self.measurement_params)
        # Per-run workbook and sheet (avoid global state).
        self.workbook = workbook or excelSheet.Workbook()
        self.sheet = self.workbook.active
    def measurementParameters(self):
        """Writes measurement parameters to the Excel sheet."""
        self.sheet["A1"] = "Measurement Parameters"
        self.sheet["A2"] = "Pixel to Inches"
        self.sheet["B2"] = self.measurement_params.get("pixel_to_inches", "N/A")
        self.sheet["A3"] = "Crop Rectangle"
        self.sheet["B3"] = str(self.measurement_params.get("crop_rect", "N/A"))
        self.sheet["A4"] = "Center Point"
        self.sheet["B4"] = str(self.measurement_params.get("center_point", "N/A"))
    
    def excel(self, video=None):
        """Formats the Excel file with summary statistics and displacement."""
        
        self.measurementParameters()
        # each column's meaning in the excel file, used for formatting the output
        column_for_excel_indexes = {
            "distance": 0,
            "distance_avg": 1,
            "distance_avg_non_red":1,
            "median": 2,
            "displacement": 3,
            "displacement_avg": 4,
            "blackfill": 5,
        }

        # Column offset for each video block (6 columns per block).
        column_offset = 4
        for video_index in range(1, (len(self.excel_values) + 1)):  # loops for each video measured

            # gets stats from the values
            values = self.excel_values["Distance" + str(video_index)]

            # Removes 0 values
            values_without_zero = [value for value in values if value != 0]

            # to avoid dividing by zero when calculating the average
            if values_without_zero == []:
                values_without_zero = [0]

            # calculates the average, median, and displacement for the distance values
            distance_average = self.getDistanceAverage(values_without_zero)
            median = self.getMedian(values_without_zero)
            displacement = self.getDisplacement(values)
            displacement_average = self.getDisplacementAverage(displacement)

            # Checks if its a list of videos or just one.
            if type(video) == str:
                # name of the test
                self.sheet[f"{self.letterValue(column_offset)}1"] = f"Test {video}"
            else:
                # name of the test
                video_name = self.list_of_videos[video_index - 1]
                
                video_stem = os.path.splitext(os.path.basename(video_name))[0]

                match = re.search(r"test[\s_-]*[a-zA-Z0-9]+", video_stem, re.IGNORECASE)
                
                test_name = match.group(0) if match else video_stem
                
                self.sheet[f"{self.letterValue(column_offset)}1"] = test_name

            # Loops for each value measured.
            video_row_offset = 2  # Offset to account for header rows in the Excel sheet.
            for row, value in enumerate(values): # +2 to get all the values and to start at row 2
                # makes cells for the distance values
                displacement_index = row 
                row += video_row_offset
                
                self.sheet[f"{self.letterValue(column_offset)}{row}"] = value
                
                #makes the last x values have a red highlight 
               # if row > len(values) - REMOVED_VALUES:
               #     self.sheet[f"{self.letterValue(column_offset)}{row}"].fill = PatternFill(start_color="FFFF0000", end_color="FFFF0000", fill_type="solid")
                    
                # makes cells for the displacement values
                self.sheet[
                f"{self.letterValue(column_offset + column_for_excel_indexes['displacement'])}{row}" ] = displacement[displacement_index] if displacement_index < len(displacement) else None
                # makes cell of a black fill for the serpration
                self.sheet[
                    f"{self.letterValue(column_offset + column_for_excel_indexes['blackfill'])}{row-1}" ].fill = BLACKFILL
    
            # Makes the cells for distance average.
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['distance_avg']))}1"] = "AVG"
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['distance_avg']))}2" ] = distance_average

            # makes average for non red values 
        #   non_red_values = values[:-REMOVED_VALUES-1]
            #non_red_average = self.getDistanceAverage(non_red_values)
           # self.sheet[
             #   f"{(self.letterValue(column_offset+column_for_excel_indexes['distance_avg_non_red']))}3"] = "Non-Red AVG"
           # self.sheet[
             #   f"{(self.letterValue(column_offset+column_for_excel_indexes['distance_avg_non_red']))}4" ] = non_red_average
            
            # Makes the cells for the median.
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['median']))}1"] = "Median"
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['median']))}2" ] = median

            # Makes the cells for the displacement.
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['displacement']))}1"] = "Displacement"
            self.sheet.column_dimensions[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['displacement']))}"].width = 12

            # Makes the cells for displacement average.
            self.sheet[
                f"{(self.letterValue(column_offset+column_for_excel_indexes['displacement_avg']))}1" ] = "AVG"
            self.sheet[
                f"{self.letterValue(column_offset+column_for_excel_indexes['displacement_avg'])}2"] = displacement_average

            # Formats the cells based on the size of each section.
            column_offset += len(column_for_excel_indexes) - 1

        # Return the workbook so callers can decide where to save it.
        return self.workbook

    ###helper functions for calculating the average, median, and displacement for the distance values
    def getDistanceAverage(self, values):
        """Gets the average of distance values."""
        return sum(values) / len(values)

    def getMedian(self, values):
        """Gets the median for distance values."""
        if not values:
            return 0
        return statistics.median(values)

    def getDisplacement(self, values):
        """Gets the displacement of the distances."""
        displacements = []
        for i in range(1, len(values)):
            displacements.append(abs(values[i] - values[i - 1]))

        return displacements

    def getDisplacementAverage(self, displacement):
        """Gets the displacement average."""
        # A single measured frame produces no displacement values, so treat
        # that case as a zero average instead of dividing by zero.
        if not displacement:
            return 0
        return sum(displacement) / len(displacement)

    def letterValue(self, i):
        """Maps a number to its corresponding Excel column letter(s)."""
        if i < 26:
            return chr(ord("A") + i)
        return chr(ord("A") + (i // 26) - 1) + chr(ord("A") + (i % 26))
